Instrucciones de Implementación

Bienvenidos a Feedback UI Desing, para cumplirlo deberán seguir lo siguiente:

1. Ver el video de explicación de reto.

2. Tienen los siguientes recursos: Entregamos el HTML con las clases correspondientes, css básico y js con la estructura que deben seguir*
   
   * En este caso les damos una estructura guía donde deben encontrar las variables e identificadores necesarios en cada caso.

3. Deberán completar el css y el js para que el reto funcione.

Resultado: El reto debe ser igual al que visualizan en el video.

¡HINTS!

CSS

 


JS

 - utiliza selectores e intruduce el fragmento de código html que requieres junto al contenido variable