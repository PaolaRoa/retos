const nav = document.querySelector('.')
window.addEventListener('', fixNav)

function fixNav() {
    if(window.> nav.offsetHeight + 150) {

    } else {
      
    }
}